$.components.register("selectpicker", {
  mode: "default",
  defaults: {
    style: "btn-select",
    iconBase: "icon",
    tickIcon: "md-check"
  }
});
