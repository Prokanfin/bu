$.components.register("dropify", {
  mode: "default",
  defaults: {}
});
