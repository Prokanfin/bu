$.components.register("maxlength", {
  mode: "default",
  defaults: {}
});
