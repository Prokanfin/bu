$.components.register("tokenfield", {
  mode: "default",
  defaults: {}
});
