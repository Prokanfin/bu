$.components.register("iCheck", {
  mode: "default",
  defaults: {}
});
