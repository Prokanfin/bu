$.components.register("tagsinput", {
  defaults: {
    tagClass: "label label-default"
  },
  mode: "default"
});
