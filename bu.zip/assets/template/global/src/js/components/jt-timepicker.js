$.components.register("timepicker", {
  mode: "default",
  defaults: {}
});
