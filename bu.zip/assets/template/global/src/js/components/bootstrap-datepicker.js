$.components.register("datepicker", {
  mode: "default",
  defaults: {
    autoclose: true
  }
});
