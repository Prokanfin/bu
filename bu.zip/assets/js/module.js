var hrApp = angular.module('hrApp',['ngRoute']);

